<?php

$config = array(
    'driver' => 'mysql',
    'host'   => 'i127.4.199.2',
    'dbname' => 'dexter500',
    'user'   => 'adminWfnb7bh',
    'password' => 'j4eLxe-595Uk'

);
