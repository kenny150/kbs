
<ul>
	<li><a href="#" target="_blank"><img src="img/icon-fb.png"
			alt="Facebook"></a></li>
	<li><a href="#" target="_blank"><img src="img/icon-tw.png"
			alt="Twitter"></a></li>
	<li><a href="#" target="_blank"><img src="img/icon-gp.png"
			alt="Google+"></a></li>
	<li><a href="#" target="_blank"><img src="img/icon-fk.png" alt="Flickr"></a>
	</li>
</ul>

<div class="copy">&copy; 2015 Dexter Curier Logistica S/A.</div>
