        <div class="sidebar">
		
		<div class="block">
			<h3>Feito por:</h3>
                       <a href="http://www.4linux.com.br" title="4Linux"><img src="images/logo4linuxsmall.png" alt="4Linux - Curso e Consultoria Linux" /></a> <br /> 
			<center><strong>Material do Treinamento da 4Linux e n&atildeo pode ser usado para outros fins. </strong></center>
		</div>
		
	</div>
