	<div id="grid_footer">
		<div class="grid_footer_center">	
			<p>Material dos Treinamentos da 4Linux.</p>
			<p>&copy;2015 4Linux. Todos os direitos reservados.</p>
		</div>
	</div>

</body>
</html>
